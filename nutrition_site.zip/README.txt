&NUTRITION 静的サイト一式
- index.html がトップページです。全ページは同じフォルダ内で相互にリンクしています。
- そのままレンタルサーバー/Netlify/Cloudflare Pages/GitHub Pages などにアップロードしてください。
- shop.html の TAG を自分のAmazonアソシエイトIDに変更してください。
